<?php
session_start(); // Inizializza la sessione

if ($_POST['password'] === 'cotroneo') { // Verifica della password
    $_SESSION['authenticated'] = true; // Imposta una variabile di sessione
    header('Location: chat.php'); // Reindirizzamento alla chat
} else {
    echo "Password errata!";
    exit();
}
?>
