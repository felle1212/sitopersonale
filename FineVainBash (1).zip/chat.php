<?php
session_start();
if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    header('Location: login.php'); // Se l'utente non è autenticato, reindirizzalo alla login
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Room</title>
    <style>
        /* Stili base per la chat */
        .chat-container {
            max-width: 800px;
            margin: 0 auto;
        }
        .chat-box {
            border: 1px solid #ddd;
            padding: 20px;
            min-height: 400px;
        }
        .message {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-box" id="chat-box">
            <!-- I messaggi verranno caricati qui tramite JavaScript -->
        </div>
        <form id="chat-form">
            <input type="text" id="message" placeholder="Scrivi un messaggio...">
            <button type="submit">Invia</button>
        </form>
    </div>

    <script>
        const chatBox = document.getElementById('chat-box');
        const form = document.getElementById('chat-form');
        const messageInput = document.getElementById('message');

        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const message = messageInput.value;

            if (message.trim() !== '') {
                // Invia il messaggio tramite AJAX al file processa_chat.php
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'processa_chat.php', true);
                xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.send('message=' + encodeURIComponent(message));

                xhr.onload = function() {
                    if (xhr.status === 200) {
                        // Aggiunge il nuovo messaggio alla chat
                        chatBox.innerHTML += `<div class="message">${message}</div>`;
                        messageInput.value = '';
                    }
                };
            }
        });

        // Carica i messaggi esistenti ogni 5 secondi
        setInterval(function() {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'fetch_chat.php', true);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    chatBox.innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        }, 5000); // Aggiorna ogni 5 secondi
    </script>
</body>
</html>
