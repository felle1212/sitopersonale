<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accesso alla Chat</title>
</head>
<body>
    <form method="post" action="processa_accesso.php">
        <label for="password">Inserisci la password:</label>
        <input type="password" id="password" name="password">
        <button type="submit">Accedi</button>
    </form>
</body>
</html>
