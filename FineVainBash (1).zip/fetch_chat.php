<?php
session_start();

if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    echo "Accesso negato!";
    exit();
}

$messages = file('chat.txt'); // Legge il contenuto del file chat.txt
foreach ($messages as $message) {
    echo "<div class='message'>{$message}</div>";
}
?>
