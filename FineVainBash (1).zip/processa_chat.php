<?php
session_start();

if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    echo "Accesso negato!";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['message'])) {
    $message = $_POST['message'];

    // Esempio di salvataggio dei messaggi nel file (chat.txt)
    $file = fopen('chat.txt', 'a'); // Apre il file in modalità append
    fwrite($file, $message . PHP_EOL); // Scrive il messaggio
    fclose($file);
}
?>

